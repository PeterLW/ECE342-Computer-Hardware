#define KEY1 0
#define KEY2 1
#define KEY3 2
